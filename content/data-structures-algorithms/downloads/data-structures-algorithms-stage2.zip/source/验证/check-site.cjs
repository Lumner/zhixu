// Run after a serialized root build: node content/data-structures-algorithms/source/验证/check-site.cjs
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '../../../../');
const out = path.join(root, 'dist');
const core = require(path.join(root, 'web/assets/core.js'));
const window = {};
const readScript = file => vm.runInNewContext(fs.readFileSync(file, 'utf8'), { window });
readScript(path.join(out, 'data/catalog.js'));
readScript(path.join(out, 'data/search.js'));
const id = 'data-structures-algorithms';
const course = window.TUTORIAL_CATALOG.courses.find(c => c.id === id);
let count = 0;
function check(label, fn) { fn(); count++; }
check('course exists and is ongoing', () => assert.equal(course?.status, 'ongoing'));
check('sixteen delivered lessons', () => assert.equal(course.chapterCount, 16));
check('stable lesson IDs', () => assert.deepEqual(Array.from(course.documents.filter(d => d.kind === 'chapter'), d => d.id), Array.from({length:16}, (_,i)=>String(i+1).padStart(2,'0'))));
check('two delivered learning stages', () => assert.equal(course.groups.length, 2));
check('registered in existing systems category', () => assert.equal(course.category, 'systems'));
check('guide does not count as lesson', () => assert.equal(course.documents.find(d => d.id === '00').kind, 'guide'));
check('download exists', () => assert.ok(fs.statSync(path.join(out, course.download)).size > 1000));
for (const term of ['容量', 'getchar', '值传递', '整数除法', '学习分钟统计器', 'realloc', '生命周期', '临时目录', '资料目录']) {
  check('course search: ' + term, () => assert.ok(core.search(term, window.TUTORIAL_SEARCH).some(item => item.courseId === id)));
}
for (const lesson of course.documents.filter(d => d.kind === 'chapter')) {
  check('lesson payload ' + lesson.id, () => {
    let payload;
    vm.runInNewContext(fs.readFileSync(path.join(out, 'data/content', id, lesson.id + '.js'), 'utf8'), {
      window: { TutorialContent: { register(key, data) { assert.equal(key, id + '/' + lesson.id); payload = data; } } }
    });
    assert.ok(payload.html.includes('完成条件'));
    assert.ok(payload.toc.length >= 8);
    if (lesson.id !== '01') assert.ok(payload.html.includes('hljs'));
  });
}
check('course progress isolation', () => {
  const store = core.createStore(null);
  store.toggleComplete(id + '/01');
  assert.equal(store.progress(course).done, 1);
  const other = window.TUTORIAL_CATALOG.courses.find(c => c.id === 'wechat-miniprogram');
  assert.equal(store.progress(other).done, 0);
  store.toggleBookmark(id + '/02');
  assert.equal(store.isBookmarked('wechat-miniprogram/02'), false);
});
const report = { date: new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Shanghai' }).format(new Date()), course: id, checks: count, passed: true, browserQA: false };
fs.writeFileSync(path.join(__dirname, '../../site-integration-checks.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report));
