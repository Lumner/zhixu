# 第一阶段完整示例与运行说明

本批有8个独立完整C程序：02—08章各1个，加阶段项目1个。第01章为手算，不冒充程序示例。所有程序只依赖标准C库，语法基线C17；源文件不需要复制其他课程的辅助头文件。

## 一、在哪里执行

Windows新手使用第02章准备的MSYS2 UCRT64 Bash；本批作者实际运行环境以 [验证记录](../验证/课程验证记录.md) 为准，没有把安装指引当成已重新安装。建议将源码复制到自己的练习目录，不在网站素材目录产生exe。

在**包含对应.c文件的目录**，命令模式是：

```bash
gcc -std=c17 -Wall -Wextra -Wpedantic hello.c -o hello.exe
./hello.exe
```

把hello替换成实际文件名。Linux已有GCC时可生成不带.exe的文件并用`./文件名`运行；PowerShell启动当前目录程序用`.\文件名.exe`，管道输入与退出状态不要直接照搬Bash语法。

## 二、每个程序的输入和结果

| 文件 | 输入、前提 | 关键输出与对应正文 |
| --- | --- | --- |
| [02-hello/hello.c](02-hello/hello.c) | 无 | Hello, algorithms!；[02章](../02-环境与第一个C程序.md) |
| [03-values/values.c](03-values/values.c) | 无，初始135分钟 | hours=2、remaining=15、integer_average=67、average=67.50、unit=m、new_total=150；[03章](../03-变量类型与运算.md) |
| [04-input/input.c](04-input/input.c) | 第一行一位0—9，允许数字后直接EOF | 3对应hours=3与minutes=180；非法行invalid input，状态1；[04章](../04-输入输出与合法数据.md) |
| [05-branches/branches.c](05-branches/branches.c) | 同上一位数字协议 | 0—4 start-small，5—7 keep-going，8—9 excellent；[05章](../05-条件判断与边界.md) |
| [06-loops/sum.c](06-loops/sum.c) | 无，n固定5，改造限定0—100 | 每轮跟踪，最后sum=15；[06章](../06-循环累加与执行跟踪.md) |
| [07-functions/functions.c](07-functions/functions.c) | 无，小整数值传递 | minutes=30、result=45、goal=60；[07章](../07-函数参数与作用域.md) |
| [08-arrays/arrays.c](08-arrays/arrays.c) | 无，5条固定记录 | 总和150、最小0、最大60、平均30、active=4、first=2；[08章](../08-数组统计与顺序查找.md) |
| [stage1-stats/stats.c](stage1-stats/stats.c) | 行协议：数量0—7；非空时n行0—1440；最后目标0—1440 | 输出完整统计；错误状态1；[阶段练习](../第一阶段-练习.md) 与 [答案](../第一阶段-参考答案.md) |

未标错误的正常执行返回0。程序未输入提示语，交互运行时按协议输入并按Enter。第一阶段错误文字也写标准输出，后续再讲标准错误与文件故障。

## 三、阶段项目复现

在**UCRT64 Bash、含stats.c的目录**：

```bash
gcc -std=c17 -Wall -Wextra -Wpedantic stats.c -o stats.exe
printf '3\n45\n15\n45\n45\n' | ./stats.exe
```

预期：count=3、total=105、min=15、max=45、average=35.00、active=3、active_average=35.00、first=0，各占一行。空记录只要输入`0`一行，程序不再要求查询目标。

源码是完整程序，正文中额外语法片段都有指定上下文。不要把片段单独编译，也不要让多个含main的例程一起链接成一个程序。
