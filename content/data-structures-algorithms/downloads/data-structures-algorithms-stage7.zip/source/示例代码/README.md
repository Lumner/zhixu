# 完整示例与运行说明

当前累计30组完整程序/工程，按下文各阶段分别统计；多文件与验证辅助程序不重复当成新项目。

第一阶段有8个独立完整C程序：02—08章各1个，加阶段项目1个。第01章为手算，不冒充程序示例。所有程序只依赖标准C库，语法基线C17；源文件不需要复制其他课程的辅助头文件。

## 一、在哪里执行

Windows新手使用第02章准备的MSYS2 UCRT64 Bash；本批作者实际运行环境以 [验证记录](../验证/课程验证记录.md) 为准，没有把安装指引当成已重新安装。建议将源码复制到自己的练习目录，不在网站素材目录产生exe。

在**包含对应.c文件的目录**，命令模式是：

```bash
gcc -std=c17 -Wall -Wextra -Wpedantic hello.c -o hello.exe
./hello.exe
```

把hello替换成实际文件名。Linux已有GCC时可生成不带.exe的文件并用`./文件名`运行；PowerShell启动当前目录程序用`.\文件名.exe`，管道输入与退出状态不要直接照搬Bash语法。

## 二、每个程序的输入和结果

| 文件 | 输入、前提 | 关键输出与对应正文 |
| --- | --- | --- |
| [02-hello/hello.c](02-hello/hello.c) | 无 | Hello, algorithms!；[02章](../02-环境与第一个C程序.md) |
| [03-values/values.c](03-values/values.c) | 无，初始135分钟 | hours=2、remaining=15、integer_average=67、average=67.50、unit=m、new_total=150；[03章](../03-变量类型与运算.md) |
| [04-input/input.c](04-input/input.c) | 第一行一位0—9，允许数字后直接EOF | 3对应hours=3与minutes=180；非法行invalid input，状态1；[04章](../04-输入输出与合法数据.md) |
| [05-branches/branches.c](05-branches/branches.c) | 同上一位数字协议 | 0—4 start-small，5—7 keep-going，8—9 excellent；[05章](../05-条件判断与边界.md) |
| [06-loops/sum.c](06-loops/sum.c) | 无，n固定5，改造限定0—100 | 每轮跟踪，最后sum=15；[06章](../06-循环累加与执行跟踪.md) |
| [07-functions/functions.c](07-functions/functions.c) | 无，小整数值传递 | minutes=30、result=45、goal=60；[07章](../07-函数参数与作用域.md) |
| [08-arrays/arrays.c](08-arrays/arrays.c) | 无，5条固定记录 | 总和150、最小0、最大60、平均30、active=4、first=2；[08章](../08-数组统计与顺序查找.md) |
| [stage1-stats/stats.c](stage1-stats/stats.c) | 行协议：数量0—7；非空时n行0—1440；最后目标0—1440 | 输出完整统计；错误状态1；[阶段练习](../第一阶段-练习.md) 与 [答案](../第一阶段-参考答案.md) |

未标错误的正常执行返回0。程序未输入提示语，交互运行时按协议输入并按Enter。第一阶段错误文字也写标准输出，后续再讲标准错误与文件故障。

## 三、阶段项目复现

在**UCRT64 Bash、含stats.c的目录**：

```bash
gcc -std=c17 -Wall -Wextra -Wpedantic stats.c -o stats.exe
printf '3\n45\n15\n45\n45\n' | ./stats.exe
```

预期：count=3、total=105、min=15、max=45、average=35.00、active=3、active_average=35.00、first=0，各占一行。空记录只要输入`0`一行，程序不再要求查询目标。

源码是完整程序，正文中额外语法片段都有指定上下文。不要把片段单独编译，也不要让多个含main的例程一起链接成一个程序。

## 四、第二阶段新增8组

平台主线仍为Windows x64、MSYS2 UCRT64 Bash、C17。第二阶段有7组小例程和1组综合工程，包含多文件时按整组统计，不把每个.c文件当一个项目。前两阶段累计16组。

| 程序或工程 | 输入与关键结果 | 正文 |
| --- | --- | --- |
| [09 strings.c](09-strings/strings.c) | 一行1—15字节文字；C basics输出bytes=8、same=1；空行与超长拒绝 | [09章](../09-字符串与整行输入.md) |
| [10 pointers.c](10-pointers/pointers.c) | 无输入；交换15/20后20/15，重绑后20/30 | [10章](../10-地址指针与生命周期.md) |
| [11 array_api.c](11-array-api/array_api.c) | 无输入；count=3、total=60、grid=6、empty_total=0 | [11章](../11-数组参数长度与const.md) |
| [12 records.c](12-records/records.c) | 无输入；副本标题和状态改变，原件保持 | [12章](../12-结构体枚举与记录.md) |
| [13 memory.c](13-memory/memory.c) | 无输入；扩容后sum=100，calloc得到三个0 | [13章](../13-动态内存与所有权.md) |
| [14 main.c](14-modules/main.c) / [totals.c](14-modules/totals.c) / [totals.h](14-modules/totals.h) | 合并编译main.c与totals.c；total=45 | [14章](../14-多文件调试与测试.md) |
| [15 file_count.c](15-files/file_count.c) | 命令行一个文件路径；输出真实字节数，打开失败stderr消息且状态1 | [15章](../15-文件命令行与错误处理.md) |
| [资料目录v0.2](stage2-catalog/README.md) | 三文件工程；导入、修改、导出与重载 | [16章](../16-综合实践资料目录v0.2.md) |

单文件仍在含.c的目录使用gcc -std=c17 -Wall -Wextra -Wpedantic 文件.c -o 文件.exe，再运行./文件.exe；每章给出具体命令。旧MinGW若不支持%zu，按第09章补充说明启用-D__USE_MINGW_ANSI_STDIO=1，不以关闭警告代替解决。实际测试环境与失败注入边界见 [第二阶段验证](../验证/第二阶段验证记录.md)。

## 五、第三阶段新增6组

第三阶段延续C17与UCRT64 Bash；累计22组完整程序/工程。多文件按一组统计，源码文件数不冒充完整程序数。

| 程序或工程 | 构建与输入 | 关键结果 |
| --- | --- | --- |
| [17 规格统计](17-specifications/main.c) / [实现](17-specifications/prefix_stats.c) / [头文件](17-specifications/prefix_stats.h) | 同目录gcc main.c prefix_stats.c -o prefix_stats.exe；无输入 | total=135 maximum=45 first_max=2 |
| [18 growth.c](18-growth/growth.c) | 编译单文件；./growth.exe 8 | linear=8 square=64 pairs=28 halves=3 |
| [19 recursion.c](19-recursion/recursion.c) | 编译单文件；无输入，n固定3 | enter3至0、leave1至3，recursive=6 iterative=6 |
| [19 hanoi.c](19-recursion/hanoi.c) | 独立编译；./hanoi.exe 2，允许0—8 | 合法移动3次，moves=3 |
| [20 查询示例](20-search/search_demo.c) / [实现](20-search/search.c) / [头文件](20-search/search.h) | 同目录gcc search_demo.c search.c -o search_demo.exe | 顺序2次、下界3次、精确二分4次元素比较 |
| [第三阶段实验台](stage3-search-lab/README.md) | main.c与共享search.c共同编译；目标由argv，数组由stdin | 检查有序前提后报告下界、最早匹配与比较次数 |

上述简写编译命令应加-std=c17 -Wall -Wextra -Wpedantic，各章给出完整命令和自己的练习目录。旧MinGW兼容选项仍见第09章；不要将多个main链接成一个程序。运行范围见 [第三阶段验证](../验证/第三阶段验证记录.md)。

## 六、第四阶段新增8组

[第四阶段构建说明](stage4-common/README.md) 包含共享头与选入口方法，[完整源码附录](stage4-common/完整源码.md) 展示全部可下载文件。平台仍是C17、UCRT64 Bash，旧MinGW格式兼容选项见第09章。

| 工程 | 学习重点 | 运行资料 |
| --- | --- | --- |
| 顺序表 | 元素位置与插入边界、搬动方向、空满 | [21章](../21-抽象数据类型与顺序表.md) |
| 动态数组 | 容量与数量、扩容失败保留、摊还与模型计数 | [22章](../22-动态数组扩容与摊还.md) |
| 单链表 | 头哨兵、前驱、接链与释放 | [23章](../23-单链表前驱与释放.md) |
| 循环双向表 | 双向不变量、首尾、稳定哨兵地址 | [24章](../24-双向与循环链表.md) |
| 栈对照 | 顺序与链两种表示，后进先出 | [25章](../25-栈与括号匹配.md) |
| 括号检查 | 类型与位置、长度/深度预算 | [25章](../25-栈与括号匹配.md) |
| 队列对照 | 循环数组绕回、链式头尾、先进先出 | [26章](../26-队列绕回与排队.md) |
| 后缀表达式 | 符号队列、值栈、左右操作数与错误 | [项目运行](stage4-expression/README.md) |

单次编译只选择一份main，完整文件组合在构建表中列明。所有拥有堆资源的对象按约定clear，不把内部元素地址作为输出变量，不复制拥有者或移动循环哨兵。实际范围见 [第四阶段验证](../验证/第四阶段验证记录.md)。

## 七、第五阶段新增4组

累计34组，完整文件组合见 [构建说明](stage5-common/README.md)，全文见 [源码附录](stage5-common/完整源码.md)。使用C17、UCRT64 Bash，不将多个main一起链接。

| 工程 | 输入与结果 | 正文 |
| --- | --- | --- |
| [匹配对照](27-matching/main.c) | 默认pi=0,0,1,2,3,0，两种算法均找到字节4；可传正文、模式 | [27章](../27-字符串匹配与KMP.md) |
| [拉链映射](28-chaining/main.c) | 同桶17,9,1；拒绝重复，删9后仍查17 | [28章](../28-散列冲突与拉链法.md) |
| [开放寻址](29-open-addressing/main.c) | 删除留墓碑，继续查16；按16格重建 | [29章](../29-开放寻址与墓碑.md) |
| [内存索引目录v0.3a](stage5-indexed-catalog/README.md) | 删17后仍查9，标题模式C匹配ID1的字节12 | [30章](../30-索引与主数据一致性.md) |

按字节匹配；映射48项预算与前三/四阶段不同，接口独立。目录不覆盖v0.2，尚未接文件和稳定排序。失败保证及真实测试见 [第五阶段验证](../验证/第五阶段验证记录.md)。

## 八、第六阶段新增7组

累计41组完整工程。五组演示覆盖九种排序，另外两组是实验台与目录v0.3；函数数、文件数、共享模块不再重复统计。C17/UCRT64命令在 [公共构建说明](stage6-common/README.md)，全部新C/H在 [完整源码](stage6-common/完整源码.md)。

| 工程 | 范围与关键结果 | 正文 |
| --- | --- | --- |
| [选择/冒泡演示](31-basic-sort/main.c) | 同样3次比较，选择颠倒同键、冒泡保序 | [31章](../31-排序规格稳定性与基础排序.md) |
| [插入/希尔演示](32-insertion-shell/main.c) | 插入有序3/3、逆序6/9；希尔反例 | [32章](../32-插入排序与希尔排序.md) |
| [归并演示](33-merge/main.c) | 5项比较8、写24，相等取左 | [33章](../33-归并排序与辅助空间.md) |
| [三路快排演示](34-quick/main.c) | 不稳定样例与全等4/0；小边递归 | [34章](../34-三路快排与递归控制.md) |
| [计数/桶/基数演示](35-distribution/main.c) | -999—999域、负数映射、完整记录稳定 | [35章](../35-计数桶与基数排序.md) |
| [排序实验台](stage6-lab/README.md) | 九算法、五种32项输入、统一比较/写入口径 | [36章](../36-排序实验与资料目录v0.3.md) |
| [资料目录v0.3](stage6-catalog/README.md) | 文件、ID索引、标题查询、稳定视图、修改/删除重载 | [36章](../36-排序实验与资料目录v0.3.md) |

辅助申请失败保留，比较与记录写入不是全部工作量。目录视图不改主顺序，文件32条与内存48条各自保留，不覆盖前版；暂无原子文件替换。实际运行见 [第六阶段验证](../验证/第六阶段验证记录.md)。

## 九、第七阶段新增7组

累计48组。共享状态头与所有新文件在 [构建说明](stage7-common/README.md) 和 [完整源码](stage7-common/完整源码.md)，七个入口分别编译，不将同名main互相覆盖。

| 工程 | 关键结果/范围 | 正文 |
| --- | --- | --- |
| [二叉树](37-binary-tree/main.c) | 5节点高3，clear为空；候选构造失败保留 | [37章](../37-树与二叉树的所有权.md) |
| [遍历](38-traversal/main.c) | 三递归/三显式栈/层序共七行 | [38章](../38-二叉树遍历与层序.md) |
| [BST](39-bst/main.c) | 拒绝重复、删根后中序1,2,3,5,6,7 | [39章](../39-二叉搜索树与删除.md) |
| [AVL插入](40-avl/main.c) | LL/RR/LR/RL根20高2；没有删除API | [40章](../40-AVL旋转与平衡.md) |
| [优先队列](41-heap/main.c) | priority再id升序，固定63项 | [41章](../41-二叉堆优先队列与堆排序.md) |
| [堆排序](41-heap/sort_main.c) | 沿用128项/统计，反例比较3写6，不稳定 | [41章](../41-二叉堆优先队列与堆排序.md) |
| [哈夫曼](42-huffman/main.c) | A110/B111/C10/D0，成本71，ABCDDA回解 | [42章](../42-哈夫曼树与前缀编解码.md) |

本批独立例程未接目录分类/路线工具；红黑/B树仅概览。新增堆排序不改旧九算法实验台；哈夫曼是有界位文本，不是压缩文件。真实验证见 [第七阶段记录](../验证/第七阶段验证记录.md)。
