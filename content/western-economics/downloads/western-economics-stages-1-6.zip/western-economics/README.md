# 西方经济学：从零理解与Python实验

课程ID：western-economics。全课规划60章，当前完成01—38章、前六阶段练习答案、33个运行入口与4个共享模块。39—60章仍是路线，后续从短期宏观行为模型开始。

先读[source/00-整体规划与学习路线.md](source/00-整体规划与学习路线.md)，再按编号学习。本批从[source/33-GDP生产边界与三种核算.md](source/33-GDP生产边界与三种核算.md)开始，涵盖GDP、物价、就业、部门收支、季度与修订。示例在[source/示例代码/stage6/运行说明.md](source/示例代码/stage6/运行说明.md)，实际结果见[source/验证/第六阶段验证记录.md](source/验证/第六阶段验证记录.md)。前38章学习程序都只需Python标准库；合成样本与官方历史少量摘录分开保留。

本地知识库集成说明见[integration-notes.md](integration-notes.md)。本次不改其他课程和共享网站文件、不构建dist；课程清单与下载包就绪后交由整合任务统一构建。分类暂复用foundations，待框架整合后移入适当经济学领域，保持ID不变。
