# 西方经济学课程整合交接

独占目录：content/western-economics/；ID稳定为western-economics。截至2026-11-13已交付01—32，规划60章，status保持ongoing。没有修改其他课程或共享基础设施。本批对01—26正文、旧21个Python文件与CSV共48个文件逐项比对哈希，均保持不变。

## 分类

当前site.config.json只有计算机相关领域。为让清单可被现有构建器发现，暂用已存在的foundations（编程与语言），对应本批确有Python零基础部分。它是兼容性临时归属，不是建议最终将经济学归为编程课。

请网站框架整合聊天统一增加合适的新领域，例如social-sciences（经济与社会科学），并将本课category迁移到它；只改分类不改course-id和章节ID，保留阅读记录。可一并评估站点描述是否继续限定“计算机知识”。本任务按根目录协作要求未改共享配置。

## 构建

先核对source/验证与下载包，再由整合任务串行运行npm run build、npm test，检查章节数32、5个已交付阶段、搜索“垄断/纳什/帕累托/外部性/公共物品/逆向选择”、17幅SVG和下载。遇到构建锁等待，不删除锁。

本课验证不等于整站构建或浏览器验收；本次未运行全站构建，也未改dist，因此当前旧网页尚不会自动显示这批新内容。应在统一构建后检查桌面、手机目录、搜索和课程隔离进度。没有发布或推送。

## 下载包

当前下载为downloads/western-economics-stages-1-5.zip，含32章清单、正文、标准库例程、数据、图解和验证。原1—3与1—4阶段ZIP都保留。maintenance/package_stage5.py只选本课源文件和必要维护资料，排除研究截图、原课件、缓存与临时文件；散列记录在package-manifest.json和package-checks.json。

第五阶段最终40项unittest、17次程序运行通过，首轮整数网格预期错误与修正说明保留。前三阶段29项/25次、第四阶段41项/17次的旧报告和源码散列仍有效，没有冒称重跑全部旧测试。累计内容检查新写content-results-stage5.json，旧content-results.json与content-results-stage4.json保留快照。
