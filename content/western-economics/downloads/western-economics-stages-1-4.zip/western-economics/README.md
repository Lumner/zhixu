# 西方经济学：从零理解与Python实验

课程ID：western-economics。全课规划60章，当前完成01—26章、前四阶段练习答案、19个运行入口与2个共享模块。27—60章只有路线，宏观正文待分批续写。

先读[source/00-整体规划与学习路线.md](source/00-整体规划与学习路线.md)，再按编号学习。新一批从[source/19-偏好效用与预算约束.md](source/19-偏好效用与预算约束.md)开始。运行方法在[source/示例代码/运行说明.md](source/示例代码/运行说明.md)，新增示例见[source/示例代码/stage4/运行说明.md](source/示例代码/stage4/运行说明.md)，实际结果见[source/验证/第四阶段验证记录.md](source/验证/第四阶段验证记录.md)。前26章学习程序都只需Python标准库。

本地知识库集成说明见[integration-notes.md](integration-notes.md)。本次不改其他课程和共享网站文件、不构建dist；课程清单与下载包就绪后交由整合任务统一构建。分类暂复用foundations，待框架整合后移入适当经济学领域，保持ID不变。
