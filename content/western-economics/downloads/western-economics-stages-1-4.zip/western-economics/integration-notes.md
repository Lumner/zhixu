# 西方经济学课程整合交接

独占目录：content/western-economics/；ID稳定为western-economics。截至2026-11-13已交付01—26，规划共60章，status必须保持ongoing，不能显示全课完成。没有修改其他课程或共享基础设施。01—18正文及原示例等30个文件哈希保持不变。

## 分类

当前site.config.json只有计算机相关领域。为让清单可被现有构建器发现，暂用已存在的foundations（编程与语言），对应本批确有Python零基础部分。它是兼容性临时归属，不是建议最终将经济学归为编程课。

请网站框架整合聊天统一增加合适的新领域，例如social-sciences（经济与社会科学），并将本课category迁移到它；只改分类不改course-id和章节ID，保留阅读记录。可一并评估站点描述是否继续限定“计算机知识”。本任务按根目录协作要求未改共享配置。

## 构建

先核对本课source/验证中的实际记录与下载包，再由整合任务串行运行npm run build、npm test，检查封面、章节数26、4个已交付阶段、搜索“机会成本/斯勒茨基/等成本线/停产/Python”、10幅SVG和下载。若存在构建锁，等待当前整合任务，不删除锁。

本课验证不等于整站构建或浏览器验收；本次未运行全站构建，也未改dist，因此当前旧网页尚不会自动显示这批新内容。应在统一构建后检查桌面、手机目录、搜索和课程隔离进度。没有发布或推送。

## 下载包

当前下载为downloads/western-economics-stages-1-4.zip，包含26章清单、正文、标准库例程、数据、图解、验证记录与交接说明。首批western-economics-stages-1-3.zip保留，不覆盖成另一批内容。新打包脚本maintenance/package_stage4.py只选本课程文件，排除研究截图、原课件、缓存和临时文件；自检散列记录保存在package-manifest.json和package-checks.json。

新程序41项unittest、17次子进程运行通过；首批29项/25次的报告保留，原源码散列匹配。累计内容检查写入source/验证/content-results-stage4.json，旧content-results.json继续保留首批快照。两个报告的范围与时间分开，不宣称全部旧测试重新运行。
