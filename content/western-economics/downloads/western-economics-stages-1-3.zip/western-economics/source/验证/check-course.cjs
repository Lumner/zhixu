/* Read-only checks of this course, except for its own JSON result file. */
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const { Marked } = require('marked');
const hljs = require('highlight.js');
const root = path.resolve(__dirname, '../..');
const source = path.join(root, 'source');
const siteRoot = path.resolve(root, '../..');
const checks = [];
function check(label, fn) { fn(); checks.push(label); }
function walk(dir) {
  return fs.readdirSync(dir, {withFileTypes:true}).flatMap(e => {
    assert.ok(!e.isSymbolicLink(), 'Unexpected symlink');
    const f = path.join(dir, e.name);
    return e.isDirectory() ? walk(f) : [f];
  });
}
const metaPath = path.join(root, process.argv.includes('--draft') ? 'maintenance/course-meta.json' : 'course.json');
const meta = JSON.parse(fs.readFileSync(metaPath, 'utf8'));
const site = JSON.parse(fs.readFileSync(path.join(siteRoot, 'site.config.json'), 'utf8'));
const files = walk(source), mdFiles = files.filter(f => f.endsWith('.md'));
const chapters = mdFiles.filter(f => path.dirname(f) === source && /^(0[1-9]|1[0-8])-/.test(path.basename(f))).sort();
check('Stable course identity and existing category', () => {
  assert.equal(meta.id, 'western-economics');
  assert.equal(meta.source, 'source');
  assert.equal(meta.status, 'ongoing');
  assert.ok(site.categories.some(x => x.id === meta.category));
});
check('Exactly eighteen real numbered chapters, no planned stubs', () => {
  assert.equal(chapters.length, 18);
  assert.equal(meta.stats.chapters, 18);
  const all = mdFiles.filter(f => path.dirname(f) === source && /^\d{2}-/.test(path.basename(f)) && !/^(00|99)-/.test(path.basename(f)));
  assert.equal(all.length, 18);
  assert.deepEqual(chapters.map(f => Number(path.basename(f).slice(0,2))), Array.from({length:18}, (_,i)=>i+1));
});
for (const file of chapters) {
  const body = fs.readFileSync(file, 'utf8');
  check('Teaching structure: ' + path.basename(file), () => {
    assert.ok(body.startsWith('# '));
    assert.ok(body.length > 1500, 'Insufficient chapter body');
    for (const heading of ['学习目标与先修','常见错误','练习与参考答案','完成条件']) assert.ok(body.includes('## ' + heading), heading);
    const n = Number(path.basename(file).slice(0,2));
    assert.equal(meta.groups.filter(g => n >= g.range[0] && n <= g.range[1]).length, 1);
  });
}
let links = 0, images = 0, codeBlocks = 0;
for (const file of mdFiles) {
  const text = fs.readFileSync(file, 'utf8');
  const parser = new Marked({walkTokens(token) {
    if (token.type === 'link' || token.type === 'image') {
      const href = token.href;
      if (/^https?:\/\//i.test(href) || href.startsWith('#')) return;
      assert.ok(!/^[a-z][a-z0-9+.-]*:/i.test(href), 'Unsupported link ' + href);
      const target = path.resolve(path.dirname(file), decodeURIComponent(href.split('#')[0]));
      assert.ok(target.startsWith(source + path.sep), 'Link leaves course source: ' + href);
      if (target !== path.join(__dirname, 'content-results.json')) {
        assert.ok(fs.existsSync(target) && fs.statSync(target).isFile(), file + ': missing ' + href);
      }
      links++;
      if(token.type === 'image') images++;
    }
    if (token.type === 'code') {
      codeBlocks++;
      if (token.lang && hljs.getLanguage(token.lang)) hljs.highlight(token.text, {language:token.lang, ignoreIllegals:true});
    }
  }});
  check('Markdown parses and local links resolve: ' + path.relative(source,file), () => {
    const html = parser.parse(text);
    assert.ok(html.length > 0);
    assert.ok(!/\uFFFD/.test(text), 'Replacement character');
    assert.equal((text.match(/^```/gm) || []).length % 2, 0, 'Unclosed fence');
  });
}
check('All three figure sets exist', () => {
  for(const name of ['market-shift','market-surplus','market-tax']) {
    const body = fs.readFileSync(path.join(source,'images', name+'.svg'),'utf8');
    assert.ok(body.includes('<svg'));
    assert.ok(!/<script\b/i.test(body));
  }
  assert.equal(images,3);
});
check('No caches, environments or run artifacts in source', () => {
  for(const file of files) assert.ok(!/[\\/](?:__pycache__|\.venv|node_modules|output)[\\/]/.test(file), file);
});
const runtime = JSON.parse(fs.readFileSync(path.join(__dirname,'example-results.json'),'utf8'));
check('Runtime report passed and covers current program hashes', () => {
  assert.equal(runtime.successful, true);
  for(const [rel, hash] of Object.entries(runtime.sourceHashes)) {
    const current=crypto.createHash('sha256').update(fs.readFileSync(path.join(source,rel))).digest('hex');
    assert.equal(current, hash, 'Stale runtime verification: '+rel);
  }
});
const report = {
  verifiedDate: '2026-11-12', timezone:'Asia/Shanghai', courseId:meta.id,
  checks:checks.length, chapters:chapters.length, markdownDocuments:mdFiles.length,
  localLinks:links, chapterImageEmbeds:images, codeBlocks, successful:true,
  scope:'Course-local metadata, teaching structure, Marked parsing, highlight.js and local file links; no site build or browser verification',
  labels:checks
};
fs.writeFileSync(path.join(__dirname,'content-results.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({...report, labels:undefined}));
