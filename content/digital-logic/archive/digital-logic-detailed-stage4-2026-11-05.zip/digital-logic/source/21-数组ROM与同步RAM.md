# 21 数组、ROM 与同步 RAM

> 零基础详细版。先修：第9章向量，第15章地址与宽度，第17章非阻塞赋值，第18章保持与更新。建议6–8小时，先画四个抽屉，再跟踪同一地址写入前后的两个版本。

**本章目标：** 区分一条多位向量与多个可寻址元素；认识ROM与RAM；建立明确的同步读写和同址冲突合同；使用实际初始化文件；用参考存储状态检查读前旧值、未初始化值和读延迟。

## 21.1 一条八位线与四个八位元素

`logic [7:0] data;`是一条八位向量。`logic [7:0] mem[0:3];`则声明四个元素，每个元素都是八位。可以类比四个编号抽屉，每个抽屉能放一张八位卡片；地址选择抽屉，数据是卡片内容。

| 写法 | 读法 | 本例数量 |
| --- | --- | --- |
| [7:0]在名字前 | 每个元素中的位范围，打包维度 | 每个8位 |
| mem[0:3] | 元素编号范围，非打包数组维度 | 4个元素 |
| mem[2] | 第2个元素 | 一整条8位 |
| mem[2][0] | 第2个元素的第0位 | 1位 |

总容量4×8=32比特，地址0…3需两位。旧工程示例中的16×8则是128比特、四位地址。本章新实验采用4×8便于逐格跟踪，没有把旧示例改小。

地址与数据是不同信息：两位地址10表示访问第2项，不表示读出的数据就是二进制10。第2项可存22、C3等任意八位模式。

## 21.2 ROM与RAM先按接口功能区分

**ROM**是只读存储器，本例内容在开始时装入，正常运行只有地址输入和数据输出，没有写使能端口。它常用于查表，例如编号到固定编码。

**RAM**是可读写存储器，本例有we写使能、addr地址和din写数据；we=1的有效沿把din写入该项。这里的“随机访问”表示可按地址直接访问，不是每次返回随机数字。

名字并不决定读延迟：ROM也可以同步读，RAM也可以描述组合读。本章刻意采用**异步读ROM与同步读RAM**，让同一个地址变化在两份输出上表现不同。选择读合同后，消费者才能知道在哪一拍使用数据。

## 21.3 同步读是什么时刻读

本RAM只在clk上升沿采样addr，并在沿后更新dout。两个沿之间即使addr改变，dout也不跟着改变。若在下降沿放好地址，下一上升沿后能读到该地址内容。

它通常被称为同步一拍读：地址在某个周期稳定后，于下一采样沿更新输出。要精确说清起点；不是输入地址后再额外等两个上升沿。如果另一个寄存器也在同一上升沿执行`consumer<=dout`，它会读旧dout，形成额外一级，这来自非阻塞采样规则。

本模型每个上升沿都会执行读取，包括we=0和we=1。we=0表示不写，不表示dout必然保持：如果沿前地址换了，沿后dout会取新地址的内容。

## 21.4 同一沿又读又写同一地址，谁先看到什么

假设mem[2]原为22，在某个有效沿we=1、addr=2、din=C3。本章规定该沿后mem[2]变C3，但dout返回**写入前的22**，叫read-first，读旧值优先。

下一个上升沿若只读地址2，则dout变C3。注意“读优先”不是说写被拒绝，也不是下一沿才真正写进去；写在前一个沿就完成了，只是同沿读出的版本是旧内容。

| 时刻 | mem[2]内容 | dout | 说明 |
| --- | --- | --- | --- |
| 写入沿前 | 22 | 可能是上次读取结果 | 先前状态 |
| 写入沿后 | C3 | 22 | 写新值，同时输出旧值 |
| 下一次同址只读沿后 | C3 | C3 | 新内容已经可读 |

![同址读写的旧值与新值](images/21-read-first.svg)

## 21.5 非阻塞赋值为何产生read-first

核心两句是`if(we) mem[addr]<=din; dout<=mem[addr];`。有效沿到来时，两句先各自计算右值；dout读取的是此刻尚未被更新的旧mem[addr]，随后存储与输出一起提交。

因此把两句位置交换，在本模型单驱动、无其他竞争的前提下仍然读旧值。若把dout的右侧改为`we ? din : mem[addr]`，就明确选择写入值，会变成write-first，而不是本章合同。

常见模式还有no-change，即写入冲突时保持先前输出。它们是不同规格，真实器件支持与推断写法要相互匹配，不能把其中一种的测试答案套到另一种。

厂商模式说明可查[AMD UG901读写同步模式](https://docs.amd.com/r/2025.1-English/ug901-vivado-synthesis/Block-RAM-Read/Write-Synchronization-Modes)，核验日期2026-11-05。本章运行的是RTL模型，没有宣称综合出的具体器件资源已经采用该模式。

## 21.6 未写过的内容为什么是X

RAM数组没有复位或初始化，四态RTL仿真开始时每项为X。第一次读未写地址，dout也为X。这表示模型没有给出已知内容，不是工具替我们选择了一个真实随机数。

真实硬件上电内容要看器件与流程，不能保证它是X、0或某个固定数。我们在本例功能合同里只保证写入后的已知内容；X检查是在验证所发布**四态RTL模型**的行为，不能当成对物理上电位值的测量。

不要只为消掉X，就给大数组加遍历清零复位。那会新增硬件语义和资源需求，可能影响块RAM推断。需要初始化时，应先明确用途与目标工具，再决定用复位、初始化文件、有效标志或软件写入等方式。

## 21.7 第三份文件rom.hex是什么

本章除design.sv、tb.sv，还需要一个纯文本文件rom.hex。它每行写一个八位十六进制值，按地址0、1、2、3顺序排列，不写`8'h`前缀：

```text
A0
B1
C2
D3
```

这是[rom.hex完整内容](时序实验/21-memory/rom.hex)。文件名不要误保存成rom.hex.txt；本例只用ASCII字符。A0表示十六进制的八位数据，不是两个待发送的文字字符“A”和“0”。

设计中`$readmemh("rom.hex",contents,0,3)`在仿真开始时把文件装入数组contents的0…3项；h表示十六进制，$readmemb则用于二进制。显式写首末索引，让装载方向清楚。

文件名相对于**运行vvp时的当前目录**解释，不自动相对于design.sv所在目录。我们要求在21-memory目录运行，就是为了让三个文件能直接配合。

## 21.8 第一份完整代码：design.sv

创建`logic-lab/21-memory/`，保存三份文件，或完整复制下载包`source/时序实验/21-memory/`。下面是[design.sv](时序实验/21-memory/design.sv)完整内容，含两种模块定义。

```systemverilog
module ram4(
  input logic clk,we,
  input logic [1:0] addr,
  input logic [7:0] din,
  output logic [7:0] dout
);
  logic [7:0] mem[0:3];
  always_ff @(posedge clk) begin
    if (we) mem[addr] <= din;
    dout <= mem[addr];
  end
endmodule

module rom4(input logic [1:0] addr,output logic [7:0] value);
  logic [7:0] contents[0:3];
  initial $readmemh("rom.hex",contents,0,3);
  assign value=contents[addr];
endmodule
```

ram4由有效沿读写；rom4将contents[addr]连续连接到value，所以地址改变可在同一虚拟时刻后重新计算输出。ROM文件初始化只执行一次，并非每次访问都重新从硬盘读取。

本例ROM中的initial用于初始化查表内容，和测试里#等待/打印不是同一用途。某些FPGA流程支持这种初始化映射，但不能泛化成所有硬件目标都支持任意initial。参考[AMD文件初始化说明](https://docs.amd.com/r/en-US/ug901-vivado-synthesis/Loading-Memory-Contents-With-File-I/O-Tasks)，核验日期2026-11-05；本批只在Icarus中运行，未进行Vivado综合。

## 21.9 第二份完整代码：tb.sv

下面是[tb.sv](时序实验/21-memory/tb.sv)完整内容。它不仅检查某次输出，还保存一份参考存储器，区分哪些地址已经写过。

```systemverilog
`timescale 1ns/1ps
module tb;
  logic clk=0,we;
  logic [1:0] addr;
  logic [7:0] din,dout,rom_value,model[0:3];
  bit known[0:3];
  integer checked_edges=0;
  ram4 dut(.clk(clk),.we(we),.addr(addr),.din(din),.dout(dout));
  rom4 lookup(.addr(addr),.value(rom_value));
  always #5 clk=~clk;
  task automatic access(input logic write_value,
      input logic [1:0] address,input logic [7:0] data_value);
    logic [7:0] expected_old,expected_rom;
    @(negedge clk); we=write_value;addr=address;din=data_value;
    expected_old=known[address] ? model[address] : 8'hxx;
    expected_rom=8'ha0+17*address;
    #1;
    if (rom_value !== expected_rom) $fatal(1,"ROM addr=%0d actual=%h expected=%h",address,rom_value,expected_rom);
    @(posedge clk); #1;
    if (dout !== expected_old)
      $fatal(1,"RAM we=%b addr=%0d actual=%h expected-old=%h",we,addr,dout,expected_old);
    if (write_value) begin model[address]=data_value;known[address]=1; end
    checked_edges++;
    $display("TRACE memory we=%b addr=%0d din=%h dout=%h",we,addr,din,dout);
  endtask
  initial begin
    we=0;addr=0;din=0;
    access(0,2'd0,8'h00);
    for (int ad=0; ad<4; ad++) access(1,ad[1:0],8'h20+ad[7:0]);
    for (int ad=0; ad<4; ad++) access(0,ad[1:0],8'h00);
    access(1,2'd2,8'hc3);
    access(0,2'd2,8'h00);
    access(0,2'd1,8'hff);
    access(0,2'd1,8'h00);
    #2;addr=2'd3; #1;
    if (dout !== 8'h21 || rom_value !== 8'hd3)
      $fatal(1,"between edges RAM must hold 21 while ROM follows addr3=D3");
    access(0,2'd3,8'h00);
    $display("PASS memory: %0d synchronous accesses, ROM file, unknown data, read-first and hold",checked_edges);
    $finish;
  end
  initial begin #300; $fatal(1,"memory timeout"); end
endmodule
```

`model[0:3]`记录参考内容，`known[0:3]`记录该项是否已有已知写入。known是bit类型，四项在测试开始时为0；这只是**测试平台的有效标志**，没有替DUT的mem做初始化。

access任务的参数依次是写使能、地址、数据。先在下降沿驱动，依据沿前参考内容建立expected_old；ROM预期由A0+17×地址得到，依次A0、B1、C2、D3；先检查组合ROM，再等上升沿后1ns检查同步RAM。

最后才将本次写入更新到model并设known=1。因此同址写入检查用的是旧版本，不会把“刚写的新数据”提前当作read-first答案。

## 21.10 为什么要逐态检查未知输出

当known[address]=0，参考旧值明确设为`8'hxx`，表示八位均未知。测试用`!==`逐态比较，要求DUT符合该模型中的未知状态；当已经写入，预期改为具体字节，未知也会触发失败。

若用普通`!=`检查未知数据，比较本身可能返回X，而if不会像确定为1那样报错，容易漏检。第9、10章的四态区别在这里成为真正的测试问题，不只是语法记忆。

这种精确X检查与“硬件保证未写内容为X”是两回事。若后续采用有初始化的RAM版本，应同时修改合同与对应预期，而不是继续拿本章未初始化测试判断它错。

## 21.11 十四次访问怎样覆盖核心行为

| 访问阶段 | 次数 | 关键预期 |
| --- | --- | --- |
| 未写先读地址0 | 1 | dout=X |
| 向0…3各写20、21、22、23 | 4 | 每项首次写同沿读旧X |
| 逐地址只读 | 4 | 依次20、21、22、23 |
| 同址把2号22改C3 | 1 | 同沿dout仍22 |
| 下一沿只读2号 | 1 | dout=C3 |
| we=0、地址1、din=FF | 1 | 只读21，不写FF |
| 再读地址1 | 1 | 仍21 |
| 最后读地址3 | 1 | dout=23 |

总数1+4+4+1+1+1+1+1=14。各次访问还检查相应ROM值。没有把14次有限序列称作所有存储器状态与读写历史的穷举。

在最后一次读取地址1之后，测试于两个上升沿之间把地址改3。RAM的dout仍为21，而ROM已变D3；到下一上升沿后，RAM才变23。这直接对照两种读时机。

## 21.12 对齐实际时刻看同址冲突

任务第一次检查在16ns，此后每次相隔10ns。第10次访问的有效沿是105ns：沿前mem[2]=22，we=1、din=C3；106ns检查dout=22。第11次在115ns只读，116ns检查dout=C3。

这个次序与第17章q2读旧q1是同一条非阻塞规则。一个是标量/向量状态，一个是数组某项状态，语言不会因为名字叫mem就自动忽略旧值。

## 21.13 运行：这次别漏第三个文件

在**21-memory目录的PowerShell**先检查目录与初始化文件，再逐条编译运行：

```powershell
Get-Location
Get-ChildItem
Get-Content .\rom.hex
iverilog -g2012 -s tb -o sim.vvp design.sv tb.sv
vvp sim.vvp
```

编译成功才运行vvp。rom.hex不用当作SystemVerilog源文件传给iverilog，它是仿真开始时由$readmemh读取的数据附件。若提示无法打开文件，先看当前目录、文件名和扩展名，不要先修改RAM的时序。

最后应有：

```text
PASS memory: 14 synchronous accesses, ROM file, unknown data, read-first and hold
```

中间TRACE可看到第一次写入的dout=xx，以及同址改写时`din=c3 dout=22`，下一次只读才`dout=c3`。这不是多打印一行旧结果的巧合，而是逐次自动比较后的真实记录。

## 21.14 两个故障分别说明什么

故障一：把dout右侧改成`we ? din : mem[addr]`。第一次写地址0时实际读出20，本合同要求旧X，测试失败，说明read-first确实被检查。后面的已知旧值22→C3也体现同一语义。

故障二：在错误副本给mem加初始全零。第一次未写先读地址0就从预期X变00，测试失败。此处是在检查发布模型的明确合同，不是在说所有初始化RAM设计都不允许存在。

两份错误副本均编译成功后在仿真中被检出。正确代码、初始化文件、日志与哈希见[第四阶段验证记录](验证/第四阶段详细重写验证记录.md)。

## 21.15 常见错误与练习

| 错误 | 误解在哪里 | 修正方法 |
| --- | --- | --- |
| 把mem[2]看成第2位 | 元素索引与位索引混淆 | 先取字节，再取位 |
| 地址变了就读同步dout | 忘了采样沿 | 标明地址建立与输出有效时刻 |
| 写同址期望立刻得到新数据 | 套了write-first合同 | 先规定冲突模式 |
| we=0认为dout一定保持 | 写使能不等于读使能 | 本例每沿读当前地址 |
| 把未写X当真实电压 | 仿真知识状态与物理位值混淆 | 分开记录模型和器件依据 |
| 从其他目录运行导致ROM加载失败 | 相对文件路径的起点错了 | 在三文件目录运行 |

练习1：8个16位元素，容量与地址位宽？8×16=128比特，地址0…7需3位。练习2：旧值A5、同沿写3C，本合同两次输出？写入沿后A5，下一次同址只读3C。练习3：we=0但换地址，输出何时更新？下一上升沿后；不是永不更新。练习4：增加一个复位端口就能保证块RAM推断吗？不能，映射还取决于器件、读写模式、复位内容和工具模板，需要真实综合报告。

## 21.16 完成条件与阶段衔接

画出数组布局，说明两种索引；独立推演同址读写两个沿；带着rom.hex运行三文件实验；检出两种合同错误并恢复；完成[第四阶段30题](第四阶段-练习与参考答案.md)和[阶段实践](第四阶段实践-时序与存储验收.md)。

接下来[第22章](22-有限状态机从状态表开始.md)将用状态编码控制多步行为。第22章以后目前仍为待详细重写原简版，交付范围以[重写进度](详细版重写进度.md)为准。
