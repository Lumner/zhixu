# 20 移位寄存器与 PWM

> 零基础详细版。先修：第9章位编号与拼接，第17章非阻塞赋值，第19章循环计数。建议5–7小时，先跟踪四位移动，再用八格纸表示一个PWM周期。

**本章目标：** 准确描述新比特从哪一端进入、旧比特往哪一端移动；区分串行位序与最终数值；由相位计数产生PWM；处理0%、100%和超范围输入；统计完整周期，而不是只看某个时刻输出高低。

## 20.1 移位寄存器保存的是一串有位置的位

普通寄存器每次可把整条数据装进去；**移位寄存器**则每次将已有位移到相邻位置，并从一端装入一个新位。若输入每次只有一位，叫串行输入；已有四位可一起读取，叫并行输出，因此它能做串并转换。

“按顺序输入1、0、1”还不足以确定最终数据，必须说明：向高位还是低位移动，新位从哪端进入，初始状态是什么，哪些沿真正移位。

本实验四位q[3:0]，复位为0000；shift_en=1时每个上升沿向高位移动，新serial_in进入q[0]。shift_en=0时保持。移位与PWM共用clk和rst，但两种功能分别计算，不把q接成相位或占空比。

## 20.2 拼接式怎样逐位读

时序赋值`q <= {q[2:0],serial_in};`的右侧总共3+1=4位：

| 新状态中的位置 | 来自沿前什么位置 |
| --- | --- |
| 新q[3] | 旧q[2] |
| 新q[2] | 旧q[1] |
| 新q[1] | 旧q[0] |
| 新q[0] | 本沿serial_in |

旧q[3]没有出现在右侧，因此被移出、丢弃；若需要串行输出，可在移位前按合同观察它。本实验没有额外serial_out端口，不把丢弃解释成自动发送到某处。

右侧q[2:0]都是旧值，由非阻塞赋值的规则一起采样。不是先把q[2]搬走，再从被改过的位置继续搬，逐行推导时也必须保留一组完整旧位。

## 20.3 手算四次移位和一次保持

| 有效移位次序 | shift_en | serial_in | 沿前q | 沿后q |
| --- | --- | --- | --- | --- |
| 1 | 1 | 1 | 0000 | 0001 |
| 2 | 1 | 0 | 0001 | 0010 |
| 3 | 1 | 1 | 0010 | 0101 |
| 4 | 1 | 1 | 0101 | 1011 |
| 暂停 | 0 | 0 | 1011 | 1011 |

四次后，最先输入的1在最高位，最后输入的1在最低位，形成1011。这依赖于本实验的左移方向。若改成`{serial_in,q[3:1]}`，新位进入最高位，第一拍就是1000，不能继续套用同一张表。

串行通信常规定先发最低位或最高位；要把发送顺序、移位方向与接收端重组方式一起分析。第25章会用这些概念解释UART数据位，不要只凭“左移/右移”两个词猜协议位序。

## 20.4 PWM先用八个格子表示

**PWM**是pulse-width modulation，中文脉宽调制。在固定重复周期里，用不同的高电平持续长度表达控制量。**占空比**是一个周期中高电平时间占总时间的比例。

把一个周期均分成8个时钟间隔，编号phase=0…7。若前3格高、后5格低，占空比3/8=37.5%；不是“电平变成0.375”，输出每个时刻仍是高或低。

```text
phase：0 1 2 3 4 5 6 7
duty3：1 1 1 0 0 0 0 0
```

本章只验证数字波形。实际负载怎样对平均效果响应，是否需要驱动电路或滤波，是另一个硬件问题，不由仿真的1/0自动完成。

![八拍PWM的三个典型占空比](images/20-pwm-slots.svg)

## 20.5 用循环相位与比较生成输出

phase是三位寄存器，每个非复位上升沿加1。三位最多7，再加1保留低三位变0，形成8状态自然回绕。注意这次周期恰好为2^3，第19章任意DIV计数不能总靠自然溢出。

定义duty为一个周期希望高的拍数。phase<duty时输出高：duty=3，只在phase=0、1、2满足；duty=0没有任何phase满足；duty=8则0…7全部满足。

相位计数器和比较器持续工作，PWM输出是当前phase、duty、rst的组合函数。它没有“每拍读一下软件计时器”的过程，也不在设计里用#等待输出脉冲。

## 20.6 为什么duty比phase多一位

phase需要表示8个编号0…7，三位足够；duty需要表示高拍数0…8，一共9种，至少四位。这与第15章“地址编号”与“占用数量”的区别一致。

本实验四位duty还能表示9…15。合同明确规定duty≥8都饱和为全高，因为所有phase都小于它；不是越界报错，也不是低三位截断回0。

| duty | 一个周期高拍数 | 占空比 |
| --- | --- | --- |
| 0 | 0 | 0% |
| 1 | 1 | 12.5% |
| 3 | 3 | 37.5% |
| 7 | 7 | 87.5% |
| 8…15 | 8 | 100% |

如果把duty端口写成三位，8接进去只剩低三位000，会把本应全亮的情况变成全灭。位宽选择本身就是功能合同的一部分。

## 20.7 第一份完整文件：design.sv

在`logic-lab/20-shift-pwm/`保存两文件，或复制下载包`source/时序实验/20-shift-pwm/`。下面是[design.sv](时序实验/20-shift-pwm/design.sv)完整内容。

```systemverilog
module shift_pwm(
  input logic clk,rst,shift_en,serial_in,
  input logic [3:0] duty,
  output logic [3:0] q,
  output logic [2:0] phase,
  output logic pwm
);
  always_ff @(posedge clk) begin
    if (rst) q <= 4'b0000;
    else if (shift_en) q <= {q[2:0],serial_in};
  end
  always_ff @(posedge clk) begin
    if (rst) phase <= 3'b000;
    else phase <= phase + 1'b1;
  end
  assign pwm=!rst && ({1'b0,phase}<duty);
endmodule
```

第一个always_ff负责q，第二个负责phase，彼此没有状态赋值交叉。rst在有效沿把两者归零，shift_en只控制移位，**不会暂停PWM相位**。

`{1'b0,phase}`把三位相位补成四位再与duty比较，双方含义和位宽都清楚。`!rst`在组合输出处屏蔽PWM，所以rst一旦变1，pwm会组合地变0，即使phase的同步复位尚未遇到上升沿。这是输出合同，不意味着phase也被异步清零。

## 20.8 为什么这里不会自动限制在周期边界改duty

假设phase=5，duty原为3，输出低；在两个时钟沿之间把duty改成7，比较立刻成立，pwm会在同一个相位内变高。周期中途的高拍分布不再是某一个固定duty完整周期的简单图样。

本实验明确采用这种**实时输入合同**，并实际检查两次不等待时钟的改变。若产品要求每个周期内部保持一致，应增加活动占空比寄存器，只在约定边界装载新值。

例如选择旧phase=7的上升沿作为回到0的边界，在该沿同时装载下一周期duty。还要规定复位值、边界前输入稳定条件和更新延迟。这是一个新设计，不是给当前模块加一句说明就算完成；本批没有交付该缓冲版本。

## 20.9 第二份完整文件：tb.sv

下面是[tb.sv](时序实验/20-shift-pwm/tb.sv)完整内容。先独立检查移位，再按完整周期统计PWM。

```systemverilog
`timescale 1ns/1ps
module tb;
  logic clk=0,rst,shift_en,serial_in,pwm;
  logic [3:0] duty,q;
  logic [2:0] phase;
  integer high_count;
  shift_pwm dut(.clk(clk),.rst(rst),.shift_en(shift_en),.serial_in(serial_in),
    .duty(duty),.q(q),.phase(phase),.pwm(pwm));
  always #5 clk=~clk;
  task automatic shift_step(input logic enable_value,bit_value,
      input logic [3:0] want);
    @(negedge clk); rst=0;shift_en=enable_value;serial_in=bit_value;
    @(posedge clk); #1;
    if (q !== want) $fatal(1,"shift en=%b bit=%b actual=%b expected=%b",shift_en,serial_in,q,want);
  endtask
  initial begin
    rst=1; shift_en=0;serial_in=0;duty=0;
    shift_step(1,1,4'b0001);
    shift_step(1,0,4'b0010);
    shift_step(1,1,4'b0101);
    shift_step(1,1,4'b1011);
    shift_step(0,0,4'b1011);
    for (int d=0; d<16; d++) begin
      @(negedge clk); rst=1;shift_en=0;duty=d[3:0];
      @(posedge clk); #1;
      if (pwm !== 1'b0 || phase !== 3'b000) $fatal(1,"PWM reset must force low/phase0");
      @(negedge clk); rst=0;
      high_count=0;
      for (int slot=0; slot<8; slot++) begin
        #1;
        if (phase !== slot[2:0] || pwm !== (slot<d))
          $fatal(1,"PWM duty=%0d slot=%0d phase=%0d pwm=%b",d,slot,phase,pwm);
        if (pwm) high_count++;
        @(posedge clk); #1;
      end
      if (high_count != ((d>=8)?8:d)) $fatal(1,"PWM high count duty=%0d count=%0d",d,high_count);
      $display("TRACE pwm duty=%0d high=%0d/8",d,high_count);
    end
    duty=0; #1;
    if (pwm !== 1'b0) $fatal(1,"live duty=0 must change output without a clock");
    duty=8; #1;
    if (pwm !== 1'b1) $fatal(1,"live duty=8 must change output without a clock");
    $display("PASS shift/PWM: 5 shift checks, 16 full frames, 128 phase samples, 2 live changes");
    $finish;
  end
  initial begin #2000; $fatal(1,"shift/PWM timeout"); end
endmodule
```

shift_step在下降沿驱动使能与串行位，上升沿后1ns核对q。五次检查对应前面的五行表。最初rst=1，在5ns上升沿清零；第一笔位在15ns采样。

PWM部分每个duty都先用复位把phase设0，并确认pwm被屏蔽为0；下一个下降沿释放rst，从phase=0开始观察。主循环遍历四位duty的全部16种二值值，不只0…8。

## 20.10 怎样避免统计窗口差一拍

每个slot先在当前相位稳定时检查phase等于slot，比较pwm是否等于slot<d；若高就将high_count加1；再等下一个上升沿推进相位，沿后再观察下一格。

因此一次完整窗口包含phase=0、1、2、3、4、5、6、7各一次，共8格。结束时已回到phase=0，但这个新周期的0不再重复计入旧周期。

只写“循环读8次”不够，还要确认每次对应哪个相位。如果从phase=1开始却认为是0，或者首尾把0算两次、中间漏7，遇到边界duty时可能得到错误统计。

## 20.11 实际结果与两次实时改变

duty=0时high=0/8，duty=3时3/8，duty=8时8/8，9…15也都是8/8。程序分别检查128个相位样本，并对每个周期核对高拍总数。

最后一帧结束后，在下一时钟沿到来前，将duty改0，等1ns检查输出低；再改8，等1ns检查输出高。它证明当前实现是组合响应duty，不是暗中寄存到下一周期。

这些有限序列覆盖移位方向、保持、全部二值duty的稳定周期和两次输入改变；没有穷举所有可能的中途改值时间与状态序列，也没有测量物理输出毛刺。

## 20.12 运行与故意改错

在**20-shift-pwm目录的PowerShell**执行：

```powershell
iverilog -g2012 -s tb -o sim.vvp design.sv tb.sv
vvp sim.vvp
```

除了16条PWM计数TRACE，最后应有：

```text
PASS shift/PWM: 5 shift checks, 16 full frames, 128 phase samples, 2 live changes
```

故障一：移位拼接改成`{serial_in,q[3:1]}`，第一笔1后得到1000，而本合同要求0001，马上失败。故障二：PWM比较把`<`改为`<=`，duty=0、phase=0竟然输出高，违背0%边界，也马上失败。两个错误副本均实际检出，正确源文件未保留错误。

## 20.13 频率、分辨率与占空比的关系

连续运行、时钟频率f_clk时，8格周期的PWM重复频率为f_clk/8。若时钟1MHz，周期8μs，重复频率125kHz。改变duty只改变高电平比例，不改变这8格周期的基本长度。

若希望有256格占空比刻度，相位需要8位，重复频率变成f_clk/256；1MHz下是3906.25Hz。输入duty若要表示0…256的100%边界，就至少9位，不能仍用8位。

增加格数可以细分占空比，但在时钟不变时会降低PWM重复频率。先根据需求计算，不要把“位数更多”自动当成所有指标都更好。

## 20.14 常见错误与练习

| 错误 | 结果 | 先检查什么 |
| --- | --- | --- |
| 没写清移位方向 | 同样串行序列重组成不同数 | 列每个新位来源 |
| shift_en误当PWM使能 | 两项功能串在一起 | 接口表分别看控制范围 |
| duty仅三位 | 无法表示8/8 | 先写0…8范围 |
| 比较用<= | duty=0也亮一格 | 检查零边界 |
| 统计相位0两次 | 完整周期高拍数不对 | 写清采样窗口 |
| 中途改duty却期待完整周期不变 | 合同与实现不一致 | 是否有边界装载寄存器 |

练习1：初值0000，输入1、1、0，按本方向三次后是什么？0001→0011→0110。练习2：phase=4、duty=4时输出？4<4为假，低；duty=5则高。练习3：duty=15有几格高？8格，因为相位只有0…7，并非15格。练习4：phase需8位、支持100%时duty几位？9位，必须表示256。

## 20.15 完成条件

独立推演串行位序；写出八格PWM表；说明duty多一位和饱和含义；运行16个完整周期，检出两个错误并恢复；解释当前实时更新合同。然后进入[第21章](21-数组ROM与同步RAM.md)，把一组状态扩成可寻址的存储内容。
