# 21 数组、ROM 与同步 RAM

本章目标：区分数组与寄存器总线，定义同步读写延迟和同址冲突。预计 3–4 小时。

## 21.1 存储器组织

`logic [7:0] mem[0:15]` 是 16 个 8 位元素，地址需要 4 位，总存储容量 128 比特。`mem[3]` 取一个字节，`mem[3][0]` 再取该字节最低位。

ROM 内容不随正常运行写入，可用 case 描述小查表。RAM 允许写入。RTL 数组不保证一定映射到片上块 RAM，是否推断成功由写法、端口、复位和目标器件共同决定。

## 21.2 同步读写合同

下面是 `10-memory` 的完整核心模块：

```systemverilog
module memory(input logic clk, we,
              input logic [3:0] addr,
              input logic [7:0] din,
              output logic [7:0] dout);
  logic [7:0] mem[0:15];
  always_ff @(posedge clk) begin
    if (we) mem[addr] <= din;
    dout <= mem[addr];
  end
endmodule
```

读地址在上升沿采样，dout 沿后得到旧存储内容。若同一沿读写同址，非阻塞赋值使 dout 取写入前的旧值，这是本模型 read-first 合同。真实器件还可能支持 write-first、no-change，必须与推断模板一致。

## 21.3 未初始化不是零

此模型不复位整个 mem，未写过的地址在四态仿真中是 X。测试先写入，再读取比较。不要为消除波形 X 随意给大数组加全量复位，这可能阻止块 RAM 推断并占用大量寄存器。

`$readmemh` 可在仿真读入十六进制初始化文件，部分 FPGA 流程也支持初始化映射，但不能据此推断所有 ASIC/器件都可综合初始化。

## 21.4 同步读与异步读

`assign dout=mem[addr]` 是异步读模型，地址改变后组合输出变化；同步读在时钟沿更新。二者延迟合同不同，连接到 CPU 或 FIFO 时必须说明数据在哪一拍有效。

## 21.5 实验与答案

`10-memory` 先逐地址写入，再回读，并检查同址旧值读取。练习：旧内容 A5，在某沿 we=1、din=3C，dout 沿后是什么？下一次同址只读是什么？答案：A5；3C。验收见[第四阶段练习](第四阶段-练习与参考答案.md)。
